from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import date, datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB = "hrms.db"


def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db()
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('Admin','HR','Employee')),
        phone TEXT, address TEXT, job_title TEXT, department TEXT,
        salary REAL DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS attendance(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        date TEXT NOT NULL,
        check_in TEXT,
        check_out TEXT,
        status TEXT NOT NULL DEFAULT 'Present',
        UNIQUE(user_id,date),
        FOREIGN KEY(user_id) REFERENCES users(id)
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS leaves(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        leave_type TEXT NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        remarks TEXT,
        status TEXT NOT NULL DEFAULT 'Pending',
        admin_comment TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS payroll(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE NOT NULL,
        basic REAL DEFAULT 0,
        hra REAL DEFAULT 0,
        allowances REAL DEFAULT 0,
        deductions REAL DEFAULT 0,
        month TEXT DEFAULT '',
        FOREIGN KEY(user_id) REFERENCES users(id)
    )''')
    conn.commit()
    admin = c.execute("SELECT id FROM users WHERE email=?", ("admin@hrms.com",)).fetchone()
    if not admin:
        c.execute("""INSERT INTO users(employee_id,name,email,password_hash,role,phone,address,job_title,department,salary)
                  VALUES(?,?,?,?,?,?,?,?,?,?)""",
                  ("ADM001","System Admin","admin@hrms.com",generate_password_hash("admin123"),"Admin","9999999999","Office","HR Manager","HR",50000))
        uid = c.lastrowid
        c.execute("INSERT INTO payroll(user_id,basic,hra,allowances,deductions,month) VALUES(?,?,?,?,?,?)",
                  (uid,30000,10000,10000,2000,"2026-07"))
        conn.commit()
    conn.close()


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get('role') not in ['Admin','HR']:
            flash('Admin/HR access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return wrapper

@app.route('/')
def home():
    return redirect(url_for('dashboard') if 'user_id' in session else url_for('login'))

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        data = request.form
        try:
            conn = db(); c = conn.cursor()
            role = data.get('role','Employee')
            if role == 'Admin': role = 'Employee'
            c.execute("""INSERT INTO users(employee_id,name,email,password_hash,role,phone,address,job_title,department,salary)
                      VALUES(?,?,?,?,?,?,?,?,?,?)""",
                      (data['employee_id'],data['name'],data['email'],generate_password_hash(data['password']),role,
                       data.get('phone',''),data.get('address',''),data.get('job_title','Employee'),data.get('department','General'),0))
            uid = c.lastrowid
            c.execute("INSERT INTO payroll(user_id,basic,hra,allowances,deductions,month) VALUES(?,?,?,?,?,?)", (uid,0,0,0,0,datetime.now().strftime('%Y-%m')))
            conn.commit(); conn.close()
            flash('Registration successful. Please login.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Employee ID or email already exists.', 'danger')
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        conn = db()
        user = conn.execute("SELECT * FROM users WHERE email=?", (request.form['email'],)).fetchone()
        conn.close()
        if user and check_password_hash(user['password_hash'], request.form['password']):
            session['user_id'] = user['id']; session['name'] = user['name']; session['role'] = user['role']
            return redirect(url_for('dashboard'))
        flash('Invalid email or password.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear(); flash('Logged out successfully.', 'success'); return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    conn = db()
    stats = {}
    if session['role'] in ['Admin','HR']:
        stats['employees'] = conn.execute("SELECT COUNT(*) total FROM users WHERE role='Employee'").fetchone()['total']
        stats['pending_leaves'] = conn.execute("SELECT COUNT(*) total FROM leaves WHERE status='Pending'").fetchone()['total']
        stats['attendance_today'] = conn.execute("SELECT COUNT(*) total FROM attendance WHERE date=?", (date.today().isoformat(),)).fetchone()['total']
    else:
        stats['my_leaves'] = conn.execute("SELECT COUNT(*) total FROM leaves WHERE user_id=?", (session['user_id'],)).fetchone()['total']
        stats['my_attendance'] = conn.execute("SELECT COUNT(*) total FROM attendance WHERE user_id=?", (session['user_id'],)).fetchone()['total']
    conn.close()
    return render_template('dashboard.html', stats=stats)

@app.route('/profile', methods=['GET','POST'])
@login_required
def profile():
    conn = db(); c = conn.cursor()
    if request.method == 'POST':
        c.execute("UPDATE users SET phone=?, address=? WHERE id=?", (request.form['phone'], request.form['address'], session['user_id']))
        conn.commit(); flash('Profile updated.', 'success')
    user = c.execute("SELECT * FROM users WHERE id=?", (session['user_id'],)).fetchone()
    conn.close()
    return render_template('profile.html', user=user)

@app.route('/employees')
@login_required
@admin_required
def employees():
    conn = db()
    users = conn.execute("SELECT * FROM users ORDER BY id DESC").fetchall()
    conn.close()
    return render_template('employees.html', users=users)

@app.route('/employees/<int:user_id>/edit', methods=['GET','POST'])
@login_required
@admin_required
def edit_employee(user_id):
    conn = db(); c = conn.cursor()
    if request.method == 'POST':
        c.execute("""UPDATE users SET name=?, phone=?, address=?, job_title=?, department=?, salary=?, role=? WHERE id=?""",
                  (request.form['name'], request.form['phone'], request.form['address'], request.form['job_title'], request.form['department'], request.form['salary'], request.form['role'], user_id))
        c.execute("INSERT OR IGNORE INTO payroll(user_id,month) VALUES(?,?)", (user_id, datetime.now().strftime('%Y-%m')))
        conn.commit(); flash('Employee updated.', 'success'); return redirect(url_for('employees'))
    user = c.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return render_template('edit_employee.html', user=user)

@app.route('/attendance', methods=['GET','POST'])
@login_required
def attendance():
    conn = db(); c = conn.cursor(); today = date.today().isoformat()
    if request.method == 'POST':
        action = request.form['action']
        now = datetime.now().strftime('%H:%M:%S')
        row = c.execute("SELECT * FROM attendance WHERE user_id=? AND date=?", (session['user_id'], today)).fetchone()
        if action == 'checkin' and not row:
            c.execute("INSERT INTO attendance(user_id,date,check_in,status) VALUES(?,?,?,?)", (session['user_id'], today, now, 'Present'))
        elif action == 'checkout' and row:
            c.execute("UPDATE attendance SET check_out=? WHERE id=?", (now, row['id']))
        conn.commit(); flash('Attendance updated.', 'success')
    if session['role'] in ['Admin','HR']:
        rows = c.execute("SELECT a.*,u.name,u.employee_id FROM attendance a JOIN users u ON a.user_id=u.id ORDER BY a.date DESC").fetchall()
    else:
        rows = c.execute("SELECT a.*,u.name,u.employee_id FROM attendance a JOIN users u ON a.user_id=u.id WHERE user_id=? ORDER BY a.date DESC", (session['user_id'],)).fetchall()
    conn.close()
    return render_template('attendance.html', rows=rows)

@app.route('/leaves', methods=['GET','POST'])
@login_required
def leaves():
    conn = db(); c = conn.cursor()
    if request.method == 'POST':
        c.execute("INSERT INTO leaves(user_id,leave_type,start_date,end_date,remarks) VALUES(?,?,?,?,?)",
                  (session['user_id'],request.form['leave_type'],request.form['start_date'],request.form['end_date'],request.form['remarks']))
        conn.commit(); flash('Leave request submitted.', 'success')
    if session['role'] in ['Admin','HR']:
        rows = c.execute("SELECT l.*,u.name,u.employee_id FROM leaves l JOIN users u ON l.user_id=u.id ORDER BY l.id DESC").fetchall()
    else:
        rows = c.execute("SELECT l.*,u.name,u.employee_id FROM leaves l JOIN users u ON l.user_id=u.id WHERE user_id=? ORDER BY l.id DESC", (session['user_id'],)).fetchall()
    conn.close()
    return render_template('leaves.html', rows=rows)

@app.route('/leaves/<int:leave_id>/<status>')
@login_required
@admin_required
def leave_action(leave_id, status):
    if status not in ['Approved','Rejected']:
        status = 'Pending'
    conn = db()
    conn.execute("UPDATE leaves SET status=?, admin_comment=? WHERE id=?", (status, f'{status} by {session["name"]}', leave_id))
    conn.commit(); conn.close(); flash(f'Leave {status.lower()}.', 'success')
    return redirect(url_for('leaves'))

@app.route('/payroll', methods=['GET','POST'])
@login_required
def payroll():
    conn = db(); c = conn.cursor()
    if request.method == 'POST' and session['role'] in ['Admin','HR']:
        uid = request.form['user_id']
        c.execute("""INSERT INTO payroll(user_id,basic,hra,allowances,deductions,month) VALUES(?,?,?,?,?,?)
                  ON CONFLICT(user_id) DO UPDATE SET basic=excluded.basic,hra=excluded.hra,allowances=excluded.allowances,deductions=excluded.deductions,month=excluded.month""",
                  (uid,request.form['basic'],request.form['hra'],request.form['allowances'],request.form['deductions'],request.form['month']))
        c.execute("UPDATE users SET salary=? WHERE id=?", (float(request.form['basic'])+float(request.form['hra'])+float(request.form['allowances'])-float(request.form['deductions']), uid))
        conn.commit(); flash('Payroll updated.', 'success')
    if session['role'] in ['Admin','HR']:
        rows = c.execute("SELECT p.*,u.name,u.employee_id FROM payroll p JOIN users u ON p.user_id=u.id").fetchall()
        users = c.execute("SELECT id,name,employee_id FROM users").fetchall()
    else:
        rows = c.execute("SELECT p.*,u.name,u.employee_id FROM payroll p JOIN users u ON p.user_id=u.id WHERE user_id=?", (session['user_id'],)).fetchall()
        users = []
    conn.close()
    return render_template('payroll.html', rows=rows, users=users)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
