# Human Resource Management System (HRMS)

A complete beginner-friendly Flask + SQLite HRMS project.

## Features
- Sign Up / Sign In
- Role based access: Admin, HR, Employee
- Employee profile management
- Attendance check-in / check-out
- Leave apply, approve and reject
- Payroll view and admin update
- Dashboard cards

## How to run

```bash
pip install -r requirements.txt
python app.py
```

Open: http://127.0.0.1:5000

## Demo Login
- Email: admin@hrms.com
- Password: admin123

## Folder Structure
```
hrms_project/
  app.py
  requirements.txt
  README.md
  hrms.db  (created automatically)
  static/style.css
  templates/*.html
```
